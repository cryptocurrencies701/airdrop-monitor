import hashlib
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import feedparser
import requests

ROOT = Path(__file__).resolve().parent
SOURCES_FILE = ROOT / "sources.json"
STATE_FILE = ROOT / "state.json"

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
MAX_ITEMS_PER_SCAN = int(os.getenv("MAX_ITEMS_PER_SCAN", "8"))

KEYWORDS = re.compile(
    r"\b(airdrop|testnet|mainnet|points|retroactive|incentive|rewards?|"
    r"claim|token launch|token generation|tge|quests?|campaign)\b",
    re.IGNORECASE,
)
EXCLUDE = re.compile(r"\b(sponsored casino|betting)\b", re.IGNORECASE)


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def save_state(state):
    STATE_FILE.write_text(
        json.dumps(state, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def telegram_send(message):
    if not BOT_TOKEN or not CHAT_ID:
        raise RuntimeError(
            "Configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID nos Secrets do GitHub."
        )
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    response = requests.post(
        url,
        json={
            "chat_id": CHAT_ID,
            "text": message[:4000],
            "disable_web_page_preview": True,
        },
        timeout=20,
    )
    response.raise_for_status()
    result = response.json()
    if not result.get("ok"):
        raise RuntimeError("Telegram recusou a mensagem; confira token e chat ID.")


def entry_id(entry, feed_url):
    link = entry.get("link", "").strip()
    title = entry.get("title", "").strip()
    raw = link or f"{feed_url}|{title}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def clean_text(value, limit=500):
    value = re.sub(r"<[^>]+>", " ", value or "")
    value = re.sub(r"\s+", " ", value).strip()
    return value[:limit]


def scan():
    if not BOT_TOKEN or not CHAT_ID:
        raise RuntimeError("Faltam TELEGRAM_BOT_TOKEN ou TELEGRAM_CHAT_ID.")

    sources = load_json(SOURCES_FILE, [])
    state = load_json(STATE_FILE, {"seen": []})
    seen = set(state.get("seen", []))
    found = []

    for source in sources:
        feed_url = source.get("url", "").strip()
        source_name = source.get("name", urlparse(feed_url).netloc or "Fonte")
        if not feed_url:
            continue
        try:
            parsed = feedparser.parse(feed_url)
            if getattr(parsed, "bozo", False) and not parsed.entries:
                print(f"Feed indisponível: {source_name}")
                continue
            for entry in parsed.entries[:40]:
                title = clean_text(entry.get("title", ""), 220)
                summary = clean_text(entry.get("summary", ""), 350)
                link = entry.get("link", "").strip()
                searchable = f"{title} {summary}"
                if not title or not link or not KEYWORDS.search(searchable):
                    continue
                if EXCLUDE.search(searchable):
                    continue
                uid = entry_id(entry, feed_url)
                if uid in seen:
                    continue
                found.append({
                    "id": uid,
                    "title": title,
                    "summary": summary,
                    "link": link,
                    "source": source_name,
                })
        except Exception as exc:
            # Do not print request URLs that might contain private query parameters.
            print(f"Erro ao consultar fonte {source_name}: {type(exc).__name__}")

    # Avoid flooding Telegram; newest items are generally first in RSS feeds.
    found = found[:MAX_ITEMS_PER_SCAN]

    if not found:
        print("Nenhuma oportunidade nova encontrada.")
        return

    sent_ids = []
    for item in found:
        message = (
            f"🔎 Possível oportunidade de airdrop\n\n"
            f"{item['title']}\n\n"
            f"Fonte: {item['source']}\n"
            f"{item['summary'] or 'Sem resumo disponível.'}\n\n"
            f"Link para verificar: {item['link']}\n\n"
            f"⚠️ Não é recomendação de investimento. Confirme no site oficial; "
            f"não informe seed phrase nem chave privada."
        )
        telegram_send(message)
        sent_ids.append(item["id"])
        time.sleep(1)

    state["seen"] = list((seen | set(sent_ids)))[-3000:]
    save_state(state)
    print(f"Enviados {len(sent_ids)} alerta(s).")


if __name__ == "__main__":
    scan()
