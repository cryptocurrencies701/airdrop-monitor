# Monitor de airdrops — protótipo gratuito

Este projeto monitora feeds RSS públicos em busca de notícias que mencionem termos como airdrop, testnet, points, rewards e claim. Envia alertas ao Telegram e registra os links já enviados.

## Limitações importantes

- Não encontra todos os airdrops da internet; depende das fontes listadas em `sources.json`.
- O filtro por palavras-chave pode produzir falsos positivos e perder oportunidades.
- O GitHub Actions executa em horários programados (4 vezes ao dia), não é um servidor 24/7 permanentemente ligado.
- O monitor não conecta nem movimenta sua carteira. Não faz transações, claims, assinaturas ou login em sites.
- Nunca informe frase-semente, chave privada ou senha de carteira a este projeto.
- Confirme cada oportunidade no site oficial. Um feed ou link pode conter conteúdo malicioso.
- Repositório público torna o código visível. Nunca grave tokens, IDs privados ou credenciais no código.
- GitHub pode atrasar execuções programadas e desativar agendas em repositórios públicos sem atividade por 60 dias.

## 1. Criar o bot no Telegram

1. Abra https://t.me/BotFather
2. Envie `/newbot`.
3. Escolha um nome e um username que termine em `bot`.
4. Guarde o token em local privado. Ele funciona como senha do bot.
5. Abra o link do seu bot e envie `/start`.

## 2. Descobrir seu Chat ID

Depois de enviar `/start` ao seu bot, abra no navegador, substituindo `SEU_TOKEN` pelo token real:

`https://api.telegram.org/botSEU_TOKEN/getUpdates`

Procure no resultado `"chat":{"id":123456789,...}`. O número após `"id"` é seu `TELEGRAM_CHAT_ID`.

**Segurança:** não compartilhe essa URL, não publique captura de tela e não cole o token em chats. Depois de copiar o ID, feche a página. Se o token vazar, use `/revoke` no BotFather e atualize o Secret no GitHub.

## 3. Criar repositório no GitHub

1. Entre em https://github.com/new.
2. Crie um repositório público chamado `airdrop-monitor` (público permite usar Actions em runners padrão sem consumir minutos pagos, mas o código ficará visível).
3. Envie todos os arquivos deste projeto mantendo os caminhos, inclusive `.github/workflows/scan.yml`.
4. Em `Settings > Secrets and variables > Actions > New repository secret`, crie:
   - `TELEGRAM_BOT_TOKEN` — token do BotFather.
   - `TELEGRAM_CHAT_ID` — número do chat obtido acima.
5. Em `Actions`, habilite workflows se o GitHub solicitar.
6. Abra `Actions > Monitor de airdrops > Run workflow` para testar.

## 4. Conferir a mensagem

Se houver notícia nova que corresponda aos termos de busca, o bot enviará um alerta. Se não houver, o log dirá `Nenhuma oportunidade nova encontrada.`

## 5. Personalizar fontes

Edite `sources.json` e acrescente feeds RSS confiáveis, preferencialmente blogs e anúncios oficiais de projetos. Formato:

```json
[
  {
    "name": "Blog oficial do projeto",
    "url": "https://exemplo.com/feed.xml"
  }
]
```

Não adicione feeds desconhecidos sem verificar a origem. Nem todo site oferece RSS. Os feeds iniciais são fontes gerais de notícias cripto, não garantem oportunidades elegíveis.

## 6. Sobre a carteira existente

Nesta primeira versão, o bot não precisa de acesso à carteira. Para monitoramento futuro, use apenas endereços públicos (somente leitura) e nunca forneça seed phrase ou chave privada. Claims e transações devem exigir confirmação manual.

## 7. Problemas comuns

- **Não chega mensagem:** confira `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` e se você iniciou conversa com o bot usando `/start`.
- **Erro 401:** token incorreto/revogado; gere outro no BotFather.
- **Erro 400 no Telegram:** confira o chat ID e se o bot pode enviar mensagem para esse chat.
- **Nenhuma oportunidade:** o filtro pode não encontrar palavras-chave nas notícias recentes; confira os logs e acrescente fontes confiáveis.
- **Agenda não roda:** confirme que o workflow está na branch padrão e que Actions está habilitado.

## Próximas melhorias

1. Fontes especializadas e páginas oficiais de campanhas.
2. Lista de tarefas e prazos.
3. Registro de projetos e pontuação de risco.
4. Monitoramento somente leitura de endereços públicos em várias redes.
5. Aprovação manual para qualquer assinatura, claim ou transação.
